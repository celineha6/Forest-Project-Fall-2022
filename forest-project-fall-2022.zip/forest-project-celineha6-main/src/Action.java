import java.util.*;

/**
 * An action that can be taken by an entity
 */
public interface Action {

    public void executeAction(EventScheduler scheduler);



}