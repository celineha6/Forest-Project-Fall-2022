import processing.core.PImage;

import java.util.List;

enum EntityKind {
    HOUSE, DUDE_FULL, DUDE_NOT_FULL, OBSTACLE, FAIRY, STUMP, SAPLING, TREE;





}

